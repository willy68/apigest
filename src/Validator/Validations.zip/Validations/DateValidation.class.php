<?php
	namespace Library\Validator\Validations;
  /*** class DateValidation ***/
  
class DateValidation extends AbstractValidation
{

	protected $format;

    public function __construct($errormsg = 'Date invalide, format valide: jj/mm/yyyy', $format = 'd/m/Y')
    {
    	parent::__construct($errormsg);
    	$this->setFormat($format);
    }
    
    public function isValid($var)
    {
    	return $this->checkDate($var);
    }

    protected function checkDate($var)
    {
    	$date = \DateTime::createFromFormat($this->format, $var);
	    if(!$date)
		    return false;

	    return true;
    }
    
	public function setFormat($format)
	{
		if (is_string($format))
			$this->format = $format;
	}

}
